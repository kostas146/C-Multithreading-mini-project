﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public void Skanuojame(string direktorija, string failas)
        {
            foreach (var failai in Directory.GetFiles(direktorija))
            {
                if (backgroundWorker1.CancellationPending)
                    return;
                lblPercentage.Invoke((Action)(() => lblStatus.Text = failai));
                if (failai.Contains(failas))
                    Pridedam(failai);
            }
            foreach (var dir in Directory.GetDirectories(direktorija))
                Skanuojame(dir, failas); // rekursija
        }


        public void Pridedam(string failas)
        {
            FileInfo fi = new FileInfo(failas);
            listView1.Invoke((Action)(() =>
            {
                var icon = Icon.ExtractAssociatedIcon(failas);
                string key = Path.GetExtension(failas);

                ListViewItem item = new ListViewItem(fi.Name, key);
                item.SubItems.Add(fi.DirectoryName);
                item.SubItems.Add(Math.Ceiling(fi.Length / 1024f).ToString("0 KB"));
                listView1.BeginUpdate();
                listView1.Items.Add(item);
                listView1.EndUpdate();
            }));
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog fbd = new FolderBrowserDialog())
            {
                if (fbd.ShowDialog() == DialogResult.OK)
                    txtPath.Text = fbd.SelectedPath;
            }
        }
        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            string[] Direktorijos = Directory.GetDirectories(txtPath.Text);
            float ilgis = Direktorijos.Length;
            progressBar1.Invoke((Action)(() => progressBar1.Maximum = Direktorijos.Length));
            Skanuojame(txtPath.Text, txtFileName.Text);
            for (int i = 0; i < Direktorijos.Length; i++)
            {
                backgroundWorker1.ReportProgress((int)(i / ilgis * 100));
                Skanuojame(Direktorijos[i], txtFileName.Text);
            }
            backgroundWorker1.ReportProgress(100);
        }
        private void backgroundWorker1_ProgressChanged_1(object sender, ProgressChangedEventArgs e)
        {
            if (!backgroundWorker1.CancellationPending)
            {
                lblPercentage.Text = e.ProgressPercentage + "%";
                progressBar1.PerformStep();
            }
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            lblStatus.Text = String.Format("Rastą {0} failų.", listView1.Items.Count);
            if (progressBar1.Value < progressBar1.Maximum)
                lblStatus.Text = "Stabdome paiešką...";
            btnSearch.Text = "Ieškoti";
        }

        private void lblPercentage_Click(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {

            if (backgroundWorker1.IsBusy)
                backgroundWorker1.CancelAsync();
            else
            {
                progressBar1.Value = progressBar1.Minimum;
                btnSearch.Text = "Stabdyti paiešką";
                listView1.Items.Clear();
                backgroundWorker1.RunWorkerAsync();
            }
        }




    }
}
