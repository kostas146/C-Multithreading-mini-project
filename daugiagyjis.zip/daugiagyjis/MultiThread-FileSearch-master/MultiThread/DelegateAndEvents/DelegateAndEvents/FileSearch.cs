﻿using System;
using System.IO;
using System.Threading;

namespace DelegateAndEvents
{
    public delegate void DGGetResult(string[] output);

    public static class MTFileSearch
    {
        public static event DGGetResult Rasti;

        public static void Search(string[] subfolders, string pattern,int progres)
        {
            foreach (string s in subfolders)
            {
                Thread thread = new Thread(() =>
                {

                    STFileSearch rasti = new STFileSearch();
                    
                  
                    rasti.OnFilesFound += new DGGetResult(getEvent);
                    rasti.Search(s, pattern, progres);
                });
                thread.Start();
            }
        }

       
        private static void getEvent(string[] result)
        {
            Rasti(result);
            return;
        }
    }


    internal class STFileSearch
    {
        internal event DGGetResult OnFilesFound;
 
        internal void Search(string dirName, string pattern,int progres)
        {
            string[] vardas = Directory.GetFiles(dirName, pattern);
            
            if (vardas.Length > 0)
            {
            
                OnFilesFound(vardas);
                progres++;
            }

            string[] subFolderiai = Directory.GetDirectories(dirName);
            foreach (string s in subFolderiai)
            {
                Search(s, pattern, progres);
            }
        }
    }
}
