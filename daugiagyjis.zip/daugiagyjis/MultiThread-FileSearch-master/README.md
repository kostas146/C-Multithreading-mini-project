# MultiThread-FileSearch
Demonstrate how C# WinForm can perform File Search with Multi-Thread processes. Select folders / subfolders, one at a time, enter the search pattern, then click the Search button. It will run new thread for each folder / subfolder specified, and search for the wildccard. Finally it will put the result in the listbox as soon as each thread completes its process.
